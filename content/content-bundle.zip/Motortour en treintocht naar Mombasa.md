# Week 1 Met de motor op pad
  
Dag 1: Aankomst in Nairobi Kosten: ongeveer $30-50 per nacht voor een hostel of $50-100 per nacht voor een hotel. Accommodatie-opties: Milimani Backpackers, Nairobi Backpackers, Nairobi Upperhill Hotel, Nairobi Serena Hotel.
  
Dag 2-3: Huur een motor in Nairobi en rijd naar Naivasha Kosten: ongeveer $20-30 per dag voor een motorfietsverhuur en $10-30 per nacht voor een guesthouse of camping. Accommodatie-opties: Camp Carnelley's, Taphe Guest Resort, Fisherman's Camp, Oloiden Campsite.

Dag 4-5: Rijd naar Nakuru National Park Kosten: ongeveer $80-100 per nacht voor een kampeerterrein of $100-150 per nacht voor een guesthouse. Accommodatie-opties: Lake Nakuru Lodge, Nakuru Backpackers, Kivu Resort.
  
Dag 6-7: Rijd naar Masai Mara National Reserve Kosten: ongeveer $80-100 per nacht voor een kampeerterrein of $100-150 per nacht voor een guesthouse. Accommodatie-opties: Mara Springs Safari Camp, Oloshaiki Campsite, Masai Mara Manyatta Camp.
  
# Week 2: Meerdaagse wandeltocht
  
Dag 8-9: Reis naar Mount Kenya National Park Kosten: ongeveer $10-30 per nacht voor een camping en $30-50 per nacht voor een guesthouse. Accommodatie-opties: Batian Guesthouse, Sirimon Bandas Campsite, Old Moses Camp.
  
Dag 10-12: Driedaagse beklimming van Mount Kenya Kosten: ongeveer $300-500 per persoon voor een georganiseerde trekking met gids, inclusief accommodatie en maaltijden in berghutten. Accommodatie-opties: Met een georganiseerde trekking zul je overnachten in berghutten langs de route.
  
Opmerking: De beklimming van Mount Kenya is geschikt voor mensen van alle leeftijden en niveaus, maar het kan fysiek uitdagend zijn. Het is belangrijk om voorafgaand aan de trekking een goede fysieke conditie te hebben en de juiste uitrusting mee te nemen.
  
Dag 13-14: Terug naar Nairobi Kosten: ongeveer $30-50 per nacht voor een hostel of $50-100 per nacht voor een hotel. Accommodatie-opties: Milimani Backpackers, Nairobi Backpackers, Nairobi Upperhill Hotel, Nairobi Serena Hotel.
  
Ik hoop dat dit plan je helpt bij het plannen van je reis naar Kenia. Houd er rekening mee dat de prijzen en accommodaties kunnen variëren, afhankelijk van het seizoen en de beschikbaarheid. Zorg ervoor dat je ruim van tevoren boekt en onderzoek doet naar de beste deals. Veel plezier met het ontdekken van Kenia!