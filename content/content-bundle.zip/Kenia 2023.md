# Algemeen
1. Waarheen: #Kenia
2. Wanneer: Juni 2023
3. Tags: #vakantie

# Plan

1.


# Tickets
| Route    | Data              | Link                                                                                                                                                                                                                                             | Prijs |
| --- | ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----- |
| AMS-NBO-AMS    | 2-26 juni         | [skyscanner](https://www.skyscanner.net/transport/flights/ams/nboa/230602/230626/?adultsv2=1&cabinclass=economy&childrenv2=&inboundaltsenabled=false&outboundaltsenabled=false&preferdirects=true&rtn=1)                                         | 719   |
| AMS-NBO-AMS    | 22 juni - 15 juli | [skyscanner](https://www.skyscanner.net/transport/vluchten/ams/nboa/230622/230715/?adults=1&adultsv2=1&cabinclass=economy&children=0&childrenv2=&inboundaltsenabled=false&infants=0&outboundaltsenabled=false&preferdirects=true&ref=home&rtn=1) | 904   |
|     |                   |                                                                                                                                                                                                                                                  |       |


# Ideeën
1. Hiken
	1.  Mount Kenya National Park - Mount Kenya is de op één na hoogste berg van Afrika en biedt een prachtig landschap en adembenemende uitzichten. Er zijn verschillende routes beschikbaar, variërend in lengte en moeilijkheidsgraad. Het is mogelijk om begeleide tochten te maken met een ervaren gids en om te kamperen in het park.
	2.  Aberdare National Park - Aberdare National Park is een bergachtig gebied dat bekend staat om zijn watervallen, wilde dieren en spectaculaire uitzichten. Er zijn verschillende wandelroutes beschikbaar, variërend in lengte en moeilijkheidsgraad. Het is mogelijk om te kamperen in het park of om te verblijven in een lodge.
		1. https://www.goatsontheroad.com/hiking-in-kenya/
		2. Mount Longonot
			1. Dagtrip vanuit Nairobi
		3. Ngong Hills, Kajiado
			1. Lange dagtrip vanuit Nairobi
		4. https://www.lonelyplanet.com/articles/best-hikes-in-kenya
	3.  Hell's Gate National Park - Hell's Gate National Park biedt een unieke ervaring voor wandelaars, omdat het mogelijk is om te wandelen tussen wilde dieren, zoals zebra's, giraffen en buffels. Er zijn verschillende wandelroutes beschikbaar, variërend in lengte en moeilijkheidsgraad. Het is mogelijk om te kamperen in het park of om te verblijven in een lodge.   
	4. Chyulu Hills National Park - Chyulu Hills National Park biedt een prachtig landschap en spectaculaire uitzichten op de Kilimanjaro. Er zijn verschillende wandelroutes beschikbaar, variërend in lengte en moeilijkheidsgraad. Het is mogelijk om te kamperen in het park of om te verblijven in een lodge.
3. Fietsen
	1. Gravel Race
		1. [Team Amani](https://www.teamamani.com/safari-gravel)
		2. [youtube](https://www.youtube.com/watch?v=Ogdde8ZdkG0)
4. Motor huren
	1. https://kenyamotorbikehire.com/Motorcycle-hire-Nairobi-Kenya.htm


# Elementen van een rondreis
1.  Maak een wandeling in de Ngong Hills: de Ngong Hills zijn een prachtig wandelgebied ten zuidwesten van Nairobi, dat veel lokale wandelaars trekt. Het biedt een prachtig uitzicht op de omgeving en is een geweldige manier om de natuurlijke schoonheid van Kenia te verkennen.
2.  Bezoek lokale markten: Kenia heeft een rijke en gevarieerde cultuur en de lokale markten zijn een geweldige manier om deze te ervaren. Bezoek bijvoorbeeld de Maasai-markt in Nairobi, waar je traditionele handgemaakte producten kunt vinden, of bezoek een lokale voedselmarkt om de culinaire cultuur van Kenia te ervaren.
3.  Ga wildkamperen: wildkamperen is een geweldige manier om de prachtige natuur van Kenia te ervaren en tegelijkertijd geld te besparen op accommodatiekosten. Er zijn verschillende locaties in Kenia waar je wild kunt kamperen, zoals Hell's Gate National Park en Lake Naivasha.
4.  Bezoek lokale gemeenschappen: Kenia heeft vele etnische gemeenschappen en het bezoeken van een lokaal dorp kan je veel leren over de lokale cultuur. Je kunt bijvoorbeeld de Maasai-dorpen bezoeken en leren over hun traditionele levensstijl en gebruiken.
5.  Beklim Mount Longonot: deze slapende vulkaan ligt ten noordwesten van Nairobi en biedt een uitdagende wandeling met een prachtig uitzicht op de Rift Valley en het nabijgelegen Naivasha-meer.
6.  Bezoek het Nairobi National Museum: het Nairobi National Museum is een geweldige manier om meer te leren over de rijke geschiedenis en cultuur van Kenia. Het museum heeft een indrukwekkende collectie van traditionele kunstvoorwerpen en artefacten, evenals een botanische tuin.
7.  Ga op safari in minder bekende parken: terwijl de bekendere parken zoals Masai Mara National Reserve populair zijn bij toeristen, zijn er veel minder bekende parken in Kenia die ook prachtige dieren in het wild hebben. Enkele voorbeelden zijn Samburu National Reserve, Tsavo East National Park en Amboseli National Park.


# Uitgewerkte reisopties
1. [[Motortour en treintocht naar Mombasa]]
2. [[Culturele rondreis]]
3. 

 


# Externe links
- Foto's:  