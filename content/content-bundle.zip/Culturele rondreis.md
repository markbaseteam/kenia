## Dag 1-2: Nairobi 
Begin uw reis in de hoofdstad Nairobi. Hier kunt u het Nairobi National Museum bezoeken om meer te leren over de geschiedenis en cultuur van Kenia. U kunt ook de lokale markten verkennen en traditionele Keniaanse gerechten proeven. Verblijf in een hostel in Nairobi, zoals Milimani Backpackers, waar u voor ongeveer $10 per nacht kunt verblijven.

Vervoermiddel: taxi of lokale bus ($2-5)
## Dag 3-4: Naivasha
Ga op weg naar het schilderachtige stadje Naivasha, gelegen aan de oevers van het gelijknamige meer. Hier kunt u een bezoek brengen aan Hell's Gate National Park, waar u kunt wandelen tussen de wilde dieren. Bezoek ook de lokale gemeenschappen in het gebied, zoals de Maasai-gemeenschappen, om meer te leren over hun cultuur en tradities. Verblijf in een budgethotel in Naivasha, zoals het Taphe Guest Resort, waar u voor ongeveer $20 per nacht kunt verblijven.

Vervoermiddel: lokale bus ($2-5)

## Dag 5-6: Kisumu
Ga verder naar Kisumu, de op twee na grootste stad van Kenia. Hier kunt u het Kisumu Museum bezoeken om meer te leren over de cultuur en geschiedenis van de lokale Luo-gemeenschap. U kunt ook het Victoria-meer verkennen en een bezoek brengen aan de lokale visserijgemeenschappen. Verblijf in een hostel in Kisumu, zoals het Dago Backpackers Hostel, waar u voor ongeveer $10 per nacht kunt verblijven.

Vervoermiddel: lokale bus ($5-10)

## Dag 7: Kakamega Forest 
Beëindig uw reis met een bezoek aan het Kakamega-bos, het enige tropische regenwoud in Kenia. Hier kunt u deelnemen aan een begeleide wandeling door het bos om de flora en fauna te verkennen. Verblijf in een budgethotel in de buurt van het bos, zoals het Rondo Retreat Centre, waar u voor ongeveer $20 per nacht kunt verblijven.

Vervoermiddel: lokale bus of taxi ($10-20)

## Samenvatting
De totale kosten voor deze reis kunnen variëren, afhankelijk van uw reisstijl en budget, maar een gemiddelde schatting zou zijn:

-   Accommodatie: $70-100 voor 7 nachten
-   Vervoer: $25-40 voor bussen en taxi's
-   Maaltijden: $50-70 voor 7 dagen
-   Bezienswaardigheden: $20-30 voor musea en parken